# PABITRA sequence asset report

- Source archive: `ezgif-88da8b1a0c34bac2-jpg.zip`
- Valid image frames extracted: 180
- Image format: JPEG
- Dimensions: 1920 × 1080 (16:9)
- First frame: `ezgif-frame-001.jpg`
- Last frame: `ezgif-frame-180.jpg`
- Numeric sequence gaps: none
- Corrupt frames detected: none
- Original filenames and bytes preserved in `public/sequence/`
- Manifest: `public/sequence/manifest.json`

The sequence depicts a BOSTON-branded apparel box and raglan T-shirt. These frames are used as supplied, without representing the garment as actual PABITRA inventory.
