# PABITRA practical legal, privacy, accessibility and SEO audit

**Review date:** 17 October 2026  
**Scope:** Source tree provided in this project ZIP. This is an implementation review, not a legal opinion or a guarantee of compliance. Production network behaviour, hosting configuration and current legal instruments still require verification.

| Issue | Location | Risk | Why it matters | Recommended fix | Status | Owner/legal review |
|---|---|---:|---|---|---|---|
| Legal business identity and contact details absent | `src/config.ts`, legal pages | High | Customers need accurate seller/contact information | Supply legal name (if applicable), address, support email/phone and grievance process | Requires owner input | Yes |
| Privacy notice is a draft | `src/LegalPages.tsx` | High | Actual processing, vendors, retention and rights handling must be described accurately | Verify all fields and operational practices; obtain qualified India-specific advice | Partially fixed | Yes |
| Terms and order acceptance | `src/LegalPages.tsx`, WhatsApp checkout | High | A prepared message is not seller acceptance | Confirm order lifecycle, price/stock confirmation, delivery and payment terms | Partially fixed | Yes |
| Return/refund policy not supplied | `/refund-policy` | High | Arbitrary deadlines or blanket exclusions could mislead customers or conflict with law | Owner to set real terms after checking applicable consumer law | Requires owner input | Yes |
| Cookie notice is a lightweight preference UI | `src/GlobalControls.tsx` | Medium/High | It is not a complete consent-management platform and does not itself block third-party requests | Audit deployed network requests; wire consent to each non-essential tracker before adding trackers | Partially fixed | Yes if tracking is enabled |
| Browser storage for cart | `src/lib/cart.ts` | Medium | Cart data persists locally; users should understand browser storage | Keep cart data minimal and document actual behaviour | Partially fixed | No, unless linked to accounts |
| External image/font hosts | `src/App.tsx`, `src/styles.css` | Medium | Browser requests can expose IP/device metadata to third parties and affect performance | Verify licences and vendor terms; consider self-hosting licensed assets | Requires owner input | Possibly |
| Supabase RLS and admin role | `supabase/migrations/001_initial_schema.sql`, admin screens | High | Frontend login alone is not authorization; policies must enforce roles server-side | Review and test every policy with anonymous, customer and admin sessions; never expose service-role keys | Requires legal/security review | Yes before launch |
| Order creation/stock atomicity | checkout and schema | High | Client totals and race conditions can create incorrect orders or overselling | Use server-side validated order creation and transactional stock reservation; test concurrency | Partially fixed / requires engineering | No |
| Product catalogue demo content | `src/data.ts`, remote editorial images | High | Placeholder items or photos must not be represented as real stock | Replace with owned/licensed images and verified inventory before launch | Requires owner input | Yes for asset rights |
| UTM attribution | Not verified in provided code | Low/Medium | Attribution should be minimised and consent-aware where required | Add only if needed, define retention and avoid sending to unapproved vendors | Not implemented | No |
| Analytics/pixels/session recording | No integration confirmed in inspected source | Medium | Trackers require configuration and possible consent controls | Inspect deployed network requests; do not assume absence solely from source scan | Requires verification | Yes if present |
| Accessibility target WCAG 2.2 AA | `src/styles.css`, components | Medium | Focus styles and skip link are improved but full conformance requires manual testing | Test keyboard, screen reader, zoom, contrast, motion and mobile touch targets | Partially fixed | No |
| SEO canonical and sitemap origin | `public/sitemap.xml`, `public/robots.txt` | Medium | Placeholder origin must not be indexed | Replace `YOUR-PRODUCTION-DOMAIN.example` with the real HTTPS origin; generate sitemap from published products | Requires owner input | No |
| 404 HTTP status and SPA fallback | Vite/hosting configuration | Medium | Client-side fallback may return HTTP 200 for unknown routes | Configure hosting to serve app shell for routes and verify status handling; add host-specific 404 rules where possible | Partially fixed | No |
| India-specific law review | Business operation | High | Applicability and commencement depend on current instruments and business model | Verify current DPDP Act/rules/notifications and Consumer Protection (E-Commerce) Rules with Indian counsel | Requires legal review | Yes |

## India-specific review notes

This project does not establish the seller's legal structure, customer age profile, data flows, business model or whether the operator is a marketplace or inventory-owning seller. These facts affect legal obligations. Before launch, qualified Indian counsel should verify the currently effective provisions, commencement notifications and final rules under the Digital Personal Data Protection Act, 2023, along with applicable consumer-protection/e-commerce rules and other laws relevant to the actual business. Do not treat draft rules or not-yet-commenced provisions as currently binding without verification.

## Launch blockers

1. Supply and verify seller identity, address and working support/grievance contacts.
2. Replace demo products and unverified remote imagery with real inventory and appropriately licensed assets.
3. Approve return, refund, shipping, payment and order acceptance policies.
4. Configure and test Supabase Auth, storage, RLS, role checks and transactional stock updates.
5. Replace placeholder production origin in sitemap/robots and configure HTTPS, SPA routing and canonical metadata.
6. Test production requests for cookies, analytics, embeds and external asset calls; wire consent to any non-essential trackers.
7. Run a full accessibility, security and cross-device QA pass. No full WCAG conformance or legal compliance claim is made.
