import {useEffect,useRef,useState} from 'react';
import {gsap} from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);
const MAX_CACHED_FRAMES=18;
const PRELOAD_AHEAD=7;

export default function Sequence(){
  const section=useRef<HTMLElement>(null),canvas=useRef<HTMLCanvasElement>(null);
  const [ordered,setOrdered]=useState<string[]>([]),[status,setStatus]=useState('Checking for sequence frames…'),[progress,setProgress]=useState(0);
  const cache=useRef(new Map<number,HTMLImageElement>()),pending=useRef(new Map<number,Promise<HTMLImageElement|null>>());
  const drawIndex=useRef(0),targetIndex=useRef(0),redrawRef=useRef<()=>void>(()=>{}),raf=useRef<number|undefined>(undefined);

  useEffect(()=>{let dead=false;fetch('/sequence/manifest.json').then(r=>r.ok?r.json():{frames:[]}).then(data=>{if(dead)return;const list:Array<string>=Array.isArray(data.frames)?data.frames:[];setOrdered(list.map(f=>f.startsWith('/')?f:`/sequence/${f}`));if(!list.length)setStatus('No sequence frames found in public/sequence/.')}).catch(()=>setStatus('Frame manifest unavailable. Add public/sequence/manifest.json.'));return()=>{dead=true}},[]);

  useEffect(()=>{
    const redraw=()=>{const c=canvas.current,ctx=c?.getContext('2d');if(!c||!ctx)return;const img=cache.current.get(drawIndex.current);if(!img?.complete||!img.naturalWidth)return;const dpr=Math.min(window.devicePixelRatio||1,1.5),w=c.clientWidth,h=c.clientHeight;if(!w||!h)return;if(c.width!==Math.round(w*dpr)||c.height!==Math.round(h*dpr)){c.width=Math.round(w*dpr);c.height=Math.round(h*dpr)}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);const scale=Math.min(w/img.naturalWidth,h/img.naturalHeight);const dw=img.naturalWidth*scale,dh=img.naturalHeight*scale;ctx.drawImage(img,(w-dw)/2,(h-dh)/2,dw,dh)};
    redrawRef.current=redraw;const resize=()=>redraw();window.addEventListener('resize',resize);return()=>window.removeEventListener('resize',resize)
  },[]);

  useEffect(()=>{
    if(!ordered.length)return;let dead=false;let trigger:ScrollTrigger|undefined;let loadedCount=0;
    const scheduleDraw=()=>{if(raf.current!==undefined)cancelAnimationFrame(raf.current);raf.current=requestAnimationFrame(()=>{raf.current=undefined;redrawRef.current()})};
    const trimCache=(keep:number)=>{const c=cache.current;if(c.size<=MAX_CACHED_FRAMES)return;const keys=[...c.keys()].sort((a,b)=>Math.abs(b-keep)-Math.abs(a-keep));while(c.size>MAX_CACHED_FRAMES&&keys.length){const k=keys.shift()!;if(Math.abs(k-keep)>3)c.delete(k)}};
    const loadFrame=(i:number)=>{if(i<0||i>=ordered.length)return Promise.resolve(null);const cached=cache.current.get(i);if(cached)return Promise.resolve(cached);const existing=pending.current.get(i);if(existing)return existing;
      const task=new Promise<HTMLImageElement|null>(resolve=>{const img=new Image();img.decoding='async';img.onload=()=>{if(dead){resolve(null);return}cache.current.set(i,img);loadedCount++;setStatus(`Loading sequence · ${Math.min(loadedCount,ordered.length)} / ${ordered.length}`);if(i===targetIndex.current){drawIndex.current=i;scheduleDraw()}trimCache(targetIndex.current);resolve(img)};img.onerror=()=>{setStatus(`A frame could not be loaded (${i+1}/${ordered.length}). Continuing sequence.`);resolve(null)};img.src=ordered[i]});pending.current.set(i,task);task.finally(()=>pending.current.delete(i));return task;
    };
    const warmAround=(i:number)=>{for(let offset=0;offset<=PRELOAD_AHEAD;offset++){if(i+offset<ordered.length)void loadFrame(i+offset);if(offset>0&&i-offset>=0)void loadFrame(i-offset)}};
    const start=async()=>{setStatus(`Loading first frame · 1 / ${ordered.length}`);const first=await loadFrame(0);if(dead)return;if(first){drawIndex.current=0;targetIndex.current=0;scheduleDraw()}warmAround(1);const st=section.current;if(!st)return;trigger=ScrollTrigger.create({trigger:st,start:'top top',end:'+=220%',pin:st.querySelector('.sequence-pin'),scrub:true,onUpdate:self=>{const idx=Math.min(ordered.length-1,Math.floor(self.progress*(ordered.length-1)));targetIndex.current=idx;setProgress(Math.round(self.progress*100));const hit=cache.current.get(idx);if(hit){drawIndex.current=idx;scheduleDraw()}else{void loadFrame(idx);warmAround(idx); // Keep the nearest already-loaded frame visible until the target arrives.
          const nearby=[...cache.current.keys()].sort((a,b)=>Math.abs(a-idx)-Math.abs(b-idx))[0];if(nearby!==undefined){drawIndex.current=nearby;scheduleDraw()}}
        }});setStatus(`${ordered.length} frames · scroll to explore`)};
    start();return()=>{dead=true;trigger?.kill();if(raf.current!==undefined)cancelAnimationFrame(raf.current);cache.current.clear();pending.current.clear();ScrollTrigger.getAll().filter(t=>t.trigger===section.current).forEach(t=>t.kill())}
  },[ordered]);

  return <section ref={section} className="sequence-section" aria-label="Scroll-controlled product story"><div className="sequence-pin"><div className="sequence-copy"><span className="eyebrow">PABITRA / OBJECT STUDY</span><h2>THE ART OF<br/><em>MOVEMENT.</em></h2><p>Scroll to explore the details.</p></div><canvas ref={canvas} className="sequence-canvas"/><div className="sequence-bottom"><span>{status}</span><div className="progress-track"><i style={{width:`${progress}%`}}/></div><span>{String(progress).padStart(2,'0')}%</span></div></div></section>
}
