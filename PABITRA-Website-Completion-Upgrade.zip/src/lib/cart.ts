import type { Product } from '../data';
export type CartLine={key:string;productId:string;name:string;slug:string;price:number;image:string;size:string;colour:string;quantity:number;stock:number};
const KEY='pabitra-cart-v1';
export const readCart=():CartLine[]=>{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch{return []}};
export const saveCart=(items:CartLine[])=>localStorage.setItem(KEY,JSON.stringify(items));
export const addLine=(items:CartLine[],p:Product,size:string,colour:string,quantity=1):CartLine[]=>{const v=p.variants.find(x=>x.size===size&&x.colour===colour);if(!v||v.stock<1)throw new Error('This variant is currently unavailable.');const key=`${p.id}|${size}|${colour}`;const old=items.find(x=>x.key===key);const next=old?items.map(x=>x.key===key?{...x,quantity:Math.min(v.stock,x.quantity+quantity)}:x):[...items,{key,productId:p.id,name:p.name,slug:p.slug,price:p.price,image:p.image,size,colour,quantity:Math.min(v.stock,quantity),stock:v.stock}];return next;};
