export const BRAND = {
  name: 'PABITRA', tagline: 'Wear your identity.', currency: 'INR', locale: 'en-IN',
  whatsappNumber: import.meta.env.VITE_WHATSAPP_NUMBER ?? '',
  instagramUrl: '', contactEmail: '', storeAddress: '', googleMapsUrl: '',
  announcement: 'NEW SEASON. NEW POINT OF VIEW.',
};
export const money = (amount: number) => new Intl.NumberFormat(BRAND.locale, {style:'currency',currency:BRAND.currency,maximumFractionDigits:0}).format(amount);
