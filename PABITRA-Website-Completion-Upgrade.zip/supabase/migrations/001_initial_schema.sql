-- PABITRA store schema. Run in Supabase SQL editor or through Supabase CLI migrations.
create extension if not exists pgcrypto;
create type public.order_status as enum ('draft','pending_whatsapp_confirmation','confirmed','processing','shipped','delivered','cancelled');
create type public.payment_status as enum ('unpaid','pending','paid','refunded');
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.categories (
  id uuid primary key default gen_random_uuid(), name text not null unique, slug text not null unique,
  description text, image_url text, sort_order int not null default 0, published boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.products (
  id uuid primary key default gen_random_uuid(), slug text not null unique, name text not null,
  description text not null default '', category_id uuid references public.categories(id) on delete set null,
  category text not null default 'Clothing', gender text not null default 'Unisex', fabric text,
  price numeric(12,2) not null check(price >= 0), compare_at numeric(12,2) check(compare_at is null or compare_at >= price),
  featured boolean not null default false, new_arrival boolean not null default false, published boolean not null default false,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.product_variants (
  id uuid primary key default gen_random_uuid(), product_id uuid not null references public.products(id) on delete cascade,
  size text not null, colour text not null, sku text not null unique, stock integer not null default 0 check(stock >= 0),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(product_id,size,colour)
);
create table public.product_images (
  id uuid primary key default gen_random_uuid(), product_id uuid not null references public.products(id) on delete cascade,
  url text not null, alt_text text not null default '', sort_order int not null default 0,
  created_at timestamptz not null default now()
);
create table public.inventory (
  id uuid primary key default gen_random_uuid(), variant_id uuid not null unique references public.product_variants(id) on delete cascade,
  stock integer not null default 0 check(stock >= 0), low_stock_threshold integer not null default 3 check(low_stock_threshold >= 0),
  updated_at timestamptz not null default now()
);
create table public.orders (
  id uuid primary key default gen_random_uuid(), order_number bigint generated always as identity unique,
  user_id uuid references auth.users(id) on delete set null, status public.order_status not null default 'pending_whatsapp_confirmation',
  payment_status public.payment_status not null default 'unpaid', customer_name text not null, customer_phone text not null,
  address text not null, city text not null, state text not null, pin_code text not null check(pin_code ~ '^[0-9]{6}$'),
  notes text, subtotal numeric(12,2) not null check(subtotal >= 0), shipping_amount numeric(12,2) not null default 0 check(shipping_amount >= 0),
  total_amount numeric(12,2) not null check(total_amount >= 0), internal_notes text,
  whatsapp_sent_confirmed_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.order_items (
  id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null, variant_id uuid references public.product_variants(id) on delete set null,
  product_name text not null, product_sku text, size text not null, colour text not null,
  quantity integer not null check(quantity > 0), unit_price numeric(12,2) not null check(unit_price >= 0), line_total numeric(12,2) not null check(line_total >= 0),
  created_at timestamptz not null default now()
);
create table public.business_settings (
  key text primary key, value jsonb not null default '{}'::jsonb, updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);
create table public.product_reviews (
  id uuid primary key default gen_random_uuid(), product_id uuid not null references public.products(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null, customer_name text not null, rating integer not null check(rating between 1 and 5),
  body text not null, verified_purchase boolean not null default false, published boolean not null default false,
  created_at timestamptz not null default now()
);
create index products_public_idx on public.products(published,featured,new_arrival);
create index products_category_idx on public.products(category_id,category);
create index variants_product_idx on public.product_variants(product_id);
create index orders_status_created_idx on public.orders(status,created_at desc);
create index orders_user_idx on public.orders(user_id,created_at desc);
create index order_items_order_idx on public.order_items(order_id);
create index reviews_product_public_idx on public.product_reviews(product_id,published);

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin');
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_variants enable row level security;
alter table public.product_images enable row level security;
alter table public.inventory enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.business_settings enable row level security;
alter table public.product_reviews enable row level security;

create policy "profiles self or admin read" on public.profiles for select to authenticated using (id=auth.uid() or public.is_admin());
create policy "profiles self insert" on public.profiles for insert to authenticated with check (id=auth.uid() and role='customer');
create policy "profiles admin update" on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public published categories" on public.categories for select to anon,authenticated using (published or public.is_admin());
create policy "admin manage categories" on public.categories for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public published products" on public.products for select to anon,authenticated using (published or public.is_admin());
create policy "admin manage products" on public.products for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public variants of published products" on public.product_variants for select to anon,authenticated using (exists(select 1 from public.products p where p.id=product_id and p.published) or public.is_admin());
create policy "admin manage variants" on public.product_variants for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public images of published products" on public.product_images for select to anon,authenticated using (exists(select 1 from public.products p where p.id=product_id and p.published) or public.is_admin());
create policy "admin manage images" on public.product_images for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public inventory for published variants" on public.inventory for select to anon,authenticated using (exists(select 1 from public.product_variants v join public.products p on p.id=v.product_id where v.id=variant_id and p.published) or public.is_admin());
create policy "admin manage inventory" on public.inventory for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "customers read own orders" on public.orders for select to authenticated using (user_id=auth.uid() or public.is_admin());
create policy "admin manage orders" on public.orders for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "customers read own order items" on public.order_items for select to authenticated using (exists(select 1 from public.orders o where o.id=order_id and o.user_id=auth.uid()) or public.is_admin());
create policy "admin manage order items" on public.order_items for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public read public settings" on public.business_settings for select to anon,authenticated using (key in ('brand','contact','shipping','policies','social','announcement') or public.is_admin());
create policy "admin manage settings" on public.business_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public published reviews" on public.product_reviews for select to anon,authenticated using (published or user_id=auth.uid() or public.is_admin());
create policy "customers submit own review" on public.product_reviews for insert to authenticated with check (user_id=auth.uid() and published=false);
create policy "admin manage reviews" on public.product_reviews for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Admin bootstrap: create the user in Supabase Auth, then run this with that user's UUID.
-- update public.profiles set role='admin' where id='YOUR_AUTH_USER_UUID';
-- Never expose the service-role key in the browser. Use a trusted server/RPC for order creation and atomic stock reservation.
